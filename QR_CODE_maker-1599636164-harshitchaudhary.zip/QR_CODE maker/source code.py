import qrcode
qr=qrcode.QRCode(  # set the dimension of QR_CODE.
	version=1,
	box_size=10,
	border=5

	)

data=" hello,this is my QR_CODE generator."  # data you want to store in QR_CODE.
qr.add_data(data) # link data to QR_CODE.
qr.make(fit=True)
img=qr.make_image(fill="black",back_color="white") # set the foreground and background color of your QR_CODE.
img.save("QR_CODE.png")
