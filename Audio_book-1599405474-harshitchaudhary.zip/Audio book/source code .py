from gtts import gTTS   #import google text-to-speech service.

import os   #import OS module for saving and accessing our files.

f=open('Story.txt') # open  text file which you want to convert into audio file.
y=f.read()

language='en'

audio=gTTS(text=y,lang=language,slow=False) # convert text into speech.

audio.save("audio_book.wav") # save audio file.
os.system("audio_book.wav") 
