import filecmp  # import library for comparing two file.
import os

files_list = os.listdir() # create list of all the files present in that specific directory.
for pics in files_list:  # iterate through all the image.
      if pics != "image1.jpg": # name of file whose similar file you want to delete.
        if filecmp.cmp("image1.jpg",pics): # compare two image.
           os.remove(pics)   # remove similar image.
           print("similar images deleted")
        else:
             print("no similar image found")
